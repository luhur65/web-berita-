<?php

require '../Function.php';

// Jika Tidak Ada Id Author yang Di URL (Hacker)
if (!isset($_GET['mod'])) {
    echo "Access Denied";
    return false;
} elseif (empty($_GET['mod'])) {
    echo "Access Denied";
    return false;
}

// Tangkap Data ID Author yg Di URL
$name = $_GET['mod'];

// Query data Author
$data  = "SELECT * FROM penulis INNER JOIN role ON role.id_role = penulis.user_role WHERE full_name = '$name'";
$query = query($data);

?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <?php foreach ($query as $row): ?>
  <title> Author Profile - <?=$row['full_name']?> </title>
  <link rel="icon" type="image/icon" href="../../img/user-icon/<?=$row['icon']?>">
  <!-- Custom fonts for this template-->
  <link href="../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../../css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
  <!-- Main Content -->
  <div id="content">

    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
      <h4 class="h3 text-primary">Author Profile</h4>
      <!-- Topbar Navbar -->
      <ul class="navbar-nav ml-auto">
        <div class="topbar-divider d-none d-sm-block"></div>
      </ul>
    </nav>

        <div class="row mx-3">
          <div class="col-sm-3 mb-4">
            <img src="../../img/user-icon/<?=$row['icon']?>" class="img-profile rounded img-fluid" >
          </div>
          <div class="col-sm">
            <table cellpadding="5" cellspacing="5">
              <tr>
                <td> <i class="fas fa-fw fa-user-alt"></i> Nama Lengkap </td>
                <td>: <span class="font-weight-bold text-gray-800"><?=$row['full_name']?></span></td>
              </tr>
              <tr>
                <td> <i class="fas fa-fw fa-venus-mars"></i> Jenis Kelamin </td>
                <td>: <span class="font-weight-bold text-gray-800"><?=$row['jenis_gender']?></span></td>
              </tr>
              <tr>
                <td> <i class="fas fa-fw fa-birthday-cake"></i> Tanggal Lahir</td>
                <td>: <span class="font-weight-bold text-gray-800"><?=$row['tgllahir']?></span></td>
              </tr>
              <tr>
                <td> <i class="fas fa-fw fa-address-card"></i> Alamat</td>
                <td>: <span class="font-weight-bold text-gray-800"><?=$row['alamat']?></span></td>
              </tr>
              <tr>
                <td> <i class="fas fa-fw  fa-mail-bulk"></i> Email Akun</td>
                <td>: <span class="font-weight-bold text-gray-800"><?=$row['email']?></span></td>
              </tr>
            </table>
          </div>
                </div>

        <div class="mt-3 mx-3">
          <a href="../../" class="btn btn-outline-primary">&larr; Kembali Ke Home Page</a>
         </div>

      </div>
      <?php endforeach;?>

  </div>










  <!-- Bootstrap core JavaScript-->
  <script src="../../vendor/jquery/jquery.min.js"></script>
  <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../../vendor/jquery/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../../vendor/jquery/sb-admin-2.min.js"></script>

</body>
</html>