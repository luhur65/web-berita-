<!-- Bootstrap core JavaScript-->
  <script src="../../vendor/jquery/jquery.min.js"></script>
  <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../../vendor/jquery/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../../vendor/jquery/sb-admin-2.min.js"></script>

  <!-- Custom scripts for alert -->
  <script src="../../vendor/alert2/sweetalert2.all.min.js"></script>

  <!-- Games Suwit -->
  <script src="../../vendor/gamesSuwit.js"></script>

  <script src="../../vendor/jquery/myscript.js"></script>

  <!-- Page level plugins -->
  <!-- <script src="vendor/chart.js/Chart.min.js"></script> -->

  <!-- Page level custom scripts -->
  <!-- <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script> -->

</body>

</html>