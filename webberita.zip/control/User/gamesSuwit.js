// Cari link Untuk Bermain Game Suwit
$('#gamejawa').on('click', function() {

	// Game Suwit Jawa Sederhana
	var tanya = true;
	while ( tanya ) {

			// Menangkap Pilihan Player
			var p = prompt('Games Suwit Jawa,  Silakan Pilih Suwitnya : \nGajah\nSemut\nOrang');



			// Menangkap Pilihan Computer
			// membangkitkan bilagan Random
			var comp = Math.random();

			if(comp < 0.34) {
				comp = 'gajah';
			} else if(comp >= 0.34 && comp < 0.67) {
				comp = 'semut';
			} else {
				comp = 'orang';
			}

			var Hasil = '';

			// Menentukan Rules
			if (p == comp ) {
				Hasil = 'Hebat , KALIAN SERI ';
			} else if(p == 'gajah') {
				Hasil = ( comp == 'orang') ? 'MENANG' : 'KALAH';
			} else if(p == 'orang') {
				Hasil = (comp == 'gajah') ? 'KALAH' : 'MENANG';
			} else if(p == 'semut') {
				Hasil = (comp = 'orang') ? 'KALAH' : 'MENANG';
			}else {
				Hasil = 'Pilihan Anda Salah ..! Masukkan Pilihan Yg Benar !! ';
			}


			// Tampilkan Hasilnya

			alert('Kamu Memilih : ' + p +' Dan Komputer Memilih '+comp+'\nMaka Hasilnya : Kamu ' + Hasil);

			tanya = confirm('Anda Ingin Bermain Lagi ???');
	}

	alert('Terima Kasih Sudah Bermain Suwit Jawa');
});

// Cari Link Untuk Bermain Tebak Angka
$('#tebakAngka').on('click' , function(){

var tanya = true;
while(tanya) {
	// game tebak angka Sederhana
	
	// random angka
		var com = Math.floor(Math.random() * 10 + 1);
	// Kunci Jawaban
		console.log(com);
		
		var p = prompt('Coba Tebak Angka Saya Dari 1 - 10 ?\nAnda Mempunyai 3x Kesempatan ');

	// Aturan Main
	// Jika Hasilnya Sama ( player Lebih Kecil Dari Komputer )
	var hasil ='Pilihan Kita Sama Yahh wkwkw !';
	if (p == com ) {

		alert('Selamat Tebakan Anda Benar !!!\nAngka Pilihan Anda '+ p +' Dan Saya Memilih Angka '+ com +'\n'+ hasil +'');
	

	// Jika Hasilnya Salah 
	// Cek Ulang Lagi
	} else if( p <= com){
		alert('Angka Yg Anda Pilih Terlalu Kecil');

		// Jika Salah Lagi 
		// Player Memassukkan Inputan Kedua 
		var p = prompt('Coba Tebak Angka Saya Dari 1 - 10 ?\nAnda Mempunyai 3x Kesempatan ');

		// Cek Jika Sama
		if (p == com ) {
	
			alert('Selamat Tebakan Anda Benar !!!\nAngka Pilihan Anda '+ p +' Dan Saya Memilih Angka '+ com +'\n'+ hasil +'');

		// Jika salah 
		} else if( p <= com) {
			alert('Angka Yg Anda Pilih Terlalu Kecil');


			// Jika Salah Lagi 
			// Player Memassukan Inputan Ketiga
			var p = prompt('Coba Tebak Angka Saya Dari 1 - 10 ?\nAnda Mempunyai 3x Kesempatan ');

			// Cek Jika Sama
			if (p == com ) {
		
				alert('Selamat Tebakan Anda Benar !!!\nAngka Pilihan Anda '+ p +' Dan Saya Memilih Angka '+ com +'\n'+ hasil +'');

			// Cek Jika Salah
			} else {
				alert('Sudah 3x Salah . Waktu Habis !!!')
			}
		} 

		// Menginput Angka
		// Jika Player Lebih Besar Dari Computer
	} else if( p >= com){
		alert('Angka Yg Anda Pilih Terlalu Besar');

		// Jika Salah Lagi 
		// Player Memassukkan Inputan Kedua 
		var p = prompt('Coba Tebak Angka Saya Dari 1 - 10 ?\nAnda Mempunyai 3x Kesempatan ');

		// Cek Jika Sama
		if (p == com ) {
	
			alert('Selamat Tebakan Anda Benar !!!\nAngka Pilihan Anda '+ p +' Dan Saya Memilih Angka '+ com +'\n'+ hasil +'');

		// Jika salah 
		} else if( p >= com) {
			alert('Angka Yg Anda Pilih Terlalu Besar');


			// Jika Salah Lagi 
			// Player Memassukan Inputan Ketiga
			var p = prompt('Coba Tebak Angka Saya Dari 1 - 10 ?\nAnda Mempunyai 3x Kesempatan ');

			// Cek Jika Sama
			if (p == com ) {
		
				alert('Selamat Tebakan Anda Benar !!!\nAngka Pilihan Anda '+ p +' Dan Saya Memilih Angka '+ com +'\n'+ hasil +'');

			// Cek Jika Salah
			} else {
				alert('Sudah 3x Salah . Waktu Habis !!!')
			}
		} 

	// Jika Memasukkan Jawaban Selain Angka
	} else {
		alert('Yang Anda Masukkan Bukan Angka !!! ');
	}

 tanya = confirm('Ingin Bermain Lagi ??');

}

alert('Terima Kasih Sudah Bermain Tebak Angka Dengan Saya');

});